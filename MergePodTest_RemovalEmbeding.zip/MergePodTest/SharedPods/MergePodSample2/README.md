# MergePodSample2

[![CI Status](https://img.shields.io/travis/Ravindra Shetty/MergePodSample2.svg?style=flat)](https://travis-ci.org/Ravindra Shetty/MergePodSample2)
[![Version](https://img.shields.io/cocoapods/v/MergePodSample2.svg?style=flat)](https://cocoapods.org/pods/MergePodSample2)
[![License](https://img.shields.io/cocoapods/l/MergePodSample2.svg?style=flat)](https://cocoapods.org/pods/MergePodSample2)
[![Platform](https://img.shields.io/cocoapods/p/MergePodSample2.svg?style=flat)](https://cocoapods.org/pods/MergePodSample2)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

MergePodSample2 is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'MergePodSample2'
```

## Author

Ravindra Shetty, ravindrashetty@phonepe.com

## License

MergePodSample2 is available under the MIT license. See the LICENSE file for more info.
