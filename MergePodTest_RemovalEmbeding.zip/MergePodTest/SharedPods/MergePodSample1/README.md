# MergePodSample1

[![CI Status](https://img.shields.io/travis/Ravindra Shetty/MergePodSample1.svg?style=flat)](https://travis-ci.org/Ravindra Shetty/MergePodSample1)
[![Version](https://img.shields.io/cocoapods/v/MergePodSample1.svg?style=flat)](https://cocoapods.org/pods/MergePodSample1)
[![License](https://img.shields.io/cocoapods/l/MergePodSample1.svg?style=flat)](https://cocoapods.org/pods/MergePodSample1)
[![Platform](https://img.shields.io/cocoapods/p/MergePodSample1.svg?style=flat)](https://cocoapods.org/pods/MergePodSample1)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

MergePodSample1 is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'MergePodSample1'
```

## Author

Ravindra Shetty, ravindrashetty@phonepe.com

## License

MergePodSample1 is available under the MIT license. See the LICENSE file for more info.
