//
//  MergePodSample1Api.swift
//  MergePodSample1
//
//  Created by Ravindra Shetty on 19/07/23.
//

import Foundation

public class MergePodSample1Api {
    public static func invokePod() {
        print("Invoked MergePodSample1 Pod")
    }
}
