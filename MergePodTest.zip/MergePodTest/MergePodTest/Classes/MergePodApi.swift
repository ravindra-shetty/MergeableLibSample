//
//  MergePodSample1Api.swift
//  MergePodSample1
//
//  Created by Ravindra Shetty on 19/07/23.
//

import Foundation

public class MergePodApi {
    public static func invokePod() {
        print("Invoked MergePod Pod")
    }
}
