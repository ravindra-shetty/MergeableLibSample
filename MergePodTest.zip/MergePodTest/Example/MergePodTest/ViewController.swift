//
//  ViewController.swift
//  MergePodTest
//
//  Created by Ravindra Shetty on 07/19/2023.
//  Copyright (c) 2023 Ravindra Shetty. All rights reserved.
//

import UIKit
import MergePodTest
import MergePodSample1
import MergePodSample2

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        MergePodApi.invokePod()
        MergePodSample1Api.invokePod()
        MergePodSample2Api.invokePod()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

