# MergePodTest

[![CI Status](https://img.shields.io/travis/Ravindra Shetty/MergePodTest.svg?style=flat)](https://travis-ci.org/Ravindra Shetty/MergePodTest)
[![Version](https://img.shields.io/cocoapods/v/MergePodTest.svg?style=flat)](https://cocoapods.org/pods/MergePodTest)
[![License](https://img.shields.io/cocoapods/l/MergePodTest.svg?style=flat)](https://cocoapods.org/pods/MergePodTest)
[![Platform](https://img.shields.io/cocoapods/p/MergePodTest.svg?style=flat)](https://cocoapods.org/pods/MergePodTest)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

MergePodTest is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'MergePodTest'
```

## Author

Ravindra Shetty, ravindrashetty@phonepe.com

## License

MergePodTest is available under the MIT license. See the LICENSE file for more info.
