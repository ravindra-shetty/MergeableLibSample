//
//  MergePodSample2Api.swift
//  MergePodSample2
//
//  Created by Ravindra Shetty on 19/07/23.
//

import Foundation

public class MergePodSample2Api {
    public static func invokePod() {
        print("Invoked MergePodSample2 Pod")
    }
}
